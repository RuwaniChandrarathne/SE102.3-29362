<!-- http://localhost/PHP1/exce_05.php -->

<?php

$fruits = array("Apple", "Banana", "Orange", "Grapes", "Mango");


foreach ($fruits as $fruit) {
    echo $fruit . "\n";
}
?>